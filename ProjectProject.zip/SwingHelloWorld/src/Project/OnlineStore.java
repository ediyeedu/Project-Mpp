package Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

    public class OnlineStore extends JFrame {
        private DefaultListModel<Item> itemListModel;
        private JList<Item> itemList;
        private DefaultListModel<Item> cartListModel;
        private JList<Item> cartList;
        private JLabel totalAmountLabel;
        private User user; // Assume the user is already created and logged in

        public OnlineStore() {
            setTitle("Online Store");
            setSize(800, 600);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            initializeComponents();
            user = new User(1, "John Doe", "john@example.com");

            addImageToFrame();
        }

        private void addImageToFrame() {
            ImageIcon imageIcon = new ImageIcon("D:\\Desktop\\SwingHelloWorld\\src\\Project\\Shopping-Online00.jpg");

            JLabel imageLabel = new JLabel(imageIcon);
            add(imageLabel, BorderLayout.BEFORE_FIRST_LINE);
        }
        public void registerUser(int id, String name, String email) {
            user = new User(id, name, email);
        }
//        public void browseItems() {
//            JFrame browseWindow = new JFrame("Browse Items");
//            JList<Item> itemList = new JList<>(itemListModel);
//            browseWindow.add(new JScrollPane(itemList));
//
//            browseWindow.setSize(400, 300);
//            browseWindow.setVisible(true);
//
//            }

public void browseItems() {
    JFrame browseWindow = new JFrame("Browse Items");
    DefaultListModel<Item> browseItemListModel = new DefaultListModel<>();


    browseItemListModel.addElement(new Item(1, "Jewelery.NeckLace", 19.99, "Description", 10));
    browseItemListModel.addElement(new Item(2, "Skirt", 29.99, "Description", 15));

    JList<Item> itemList = new JList<>(browseItemListModel);
    browseWindow.add(new JScrollPane(itemList));

    browseWindow.setSize(400, 300);
    browseWindow.setVisible(true);
}
            private void initializeComponents() {
            itemListModel = new DefaultListModel<>();
            itemList = new JList<>(itemListModel);
            cartListModel = new DefaultListModel<>();
            cartList = new JList<>(cartListModel);
            totalAmountLabel = new JLabel("Total: $0.00");


            itemListModel.addElement(new Item(1, "Jewelery.NeckLace", 19.99, "Description", 10));
            itemListModel.addElement(new Item(2, "Skirt", 29.99, "Description", 15));
            // ... add more items

            JButton addButton = new JButton("Add to Cart");
            addButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Item selectedItem = itemList.getSelectedValue();
                    if (selectedItem != null) {
                        cartListModel.addElement(selectedItem);
                        user.getShoppingCart().addItem(selectedItem);
                        updateTotalAmount();

                    }
                }
            });
            JButton browseButton = new JButton("Browse Items");
            browseButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    browseItems();
                }
            });
                add(browseButton, BorderLayout.CENTER);

                JButton removeButton = new JButton("Remove from Cart");
            removeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Item selectedItem = cartList.getSelectedValue();
                    if (selectedItem != null) {
                        cartListModel.removeElement(selectedItem);
                        user.getShoppingCart().removeItem(selectedItem);
                        updateTotalAmount();
                    }
                }
            });
            JButton purchaseButton = new JButton("Purchase");
            purchaseButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    user.purchaseItems();
                    cartListModel.clear();
                    updateTotalAmount();

                }
            });
            // Add components to the frame
            add(new JScrollPane(itemList), BorderLayout.WEST);
            add(new JScrollPane(cartList), BorderLayout.EAST);
            JPanel bottomPanel = new JPanel();
            bottomPanel.add(purchaseButton);
            bottomPanel.add(addButton);
            bottomPanel.add(removeButton);
            bottomPanel.add(totalAmountLabel);
            add(bottomPanel, BorderLayout.SOUTH);
        }

        private void updateTotalAmount() {
            double total = user.getShoppingCart().getTotalAmount();
            totalAmountLabel.setText(String.format("Total: $%.2f", total));
        }

        public static void main(String[] args) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    new OnlineStore().setVisible(true);
                }
            });
        }
    }

