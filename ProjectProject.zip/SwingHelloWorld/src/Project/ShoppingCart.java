package Project;

import java.util.ArrayList;
import java.util.List;

    public class ShoppingCart {
        private List<Item> items;
        private double totalAmount;

        public ShoppingCart() {
            items = new ArrayList<>();
            totalAmount = 0.0;
        }

        public void addItem(Item item) {
            items.add(item);
            totalAmount += item.getPrice();
        }
            public void purchaseItems() {
                for (Item item : items) {
                    item.purchaseItem();
                    int remainingQuantity = item.getStockQuantity() - 1;
                    if (remainingQuantity <= 0) {
                        items.remove(item);
                    } else {
                        item.setStockQuantity(remainingQuantity);
                    }
                }

                items.clear(); // Clear the cart after purchase
                totalAmount = 0.0; // Reset total amount
            }
            public void removeItem(Item item) {
            items.remove(item);
            totalAmount -= item.getPrice();
        }
        public List<Item> getItems() {
            return items;
        }

        public double getTotalAmount() {
            return totalAmount;
        }
    }

